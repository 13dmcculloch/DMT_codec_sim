# -*- coding: utf-8 -*-
"""
DMT codec.
Todo:
    Add synchronisation functions (CP & amble correlation)
    Add selective mapping so pilot symbol can be used
    Require preamble and end of transmission packets specifically

Created on Thu Nov  7 12:26:20 2024

@author: drm1g20
"""

import numpy as np

import modulations
import sys
import os

def DMT_modulate(f_data,
                 n_subcarriers=32,
                 pilots=(31,),
                 modulation_format='bpsk',
                 cp_length=32//4):
    """
    Modulate ASCII bits in f_data file object to DMT symbols ndarray
    """
    signal = []
    
    n_pilots = len(pilots)
    n_data_subcarriers = n_subcarriers - n_pilots - 1  # DC (SC 0) is 0
    
    modulation_order = modulations.modulation_order(modulation_format)
    
    while f_data.readable():
        # serial to parallel
        n_read = n_data_subcarriers * modulation_order
        strbuf = f_data.read(n_read * 2)  # includes '\n'
        if strbuf == '':
            break
        buffer = np.fromstring(strbuf,
                               sep='\n',
                               dtype=int)
        
        # pad with zeroes if buffer incomplete
        if len(buffer) != n_read and len(strbuf) > 0:
            fullbuf = np.zeros(n_read,
                               dtype=int)
            fullbuf[:len(buffer)] = buffer
            buffer = fullbuf
    
        # mapping
        data = modulations.modulate_data(buffer,
                                         modulation_format=modulation_format)
        pilot_symbol = np.real(np.max(data))
        
        # prepare ifft buffer
        bins = np.zeros(n_subcarriers,
                        dtype=complex)
        bins[1:len(data)+1] = data
        bins[len(bins)-1] = pilot_symbol
        
        bins_conj = np.zeros(n_subcarriers,
                        dtype=complex)
        bins_conj[1:] = np.flip(np.conjugate(bins[1:]))
        
        ifft_bins = np.concatenate((bins, bins_conj))

        # perform IFFT
        ifft_out = np.fft.ifft(ifft_bins)
        if not np.all(np.imag(ifft_out) == 0):
            print("IFFT output has imaginary part:")
            print(ifft_out)
            return
        ifft_out = np.real(ifft_out)
        
        # parallel to serial; add CP
        symbol = np.zeros(n_subcarriers*2 + cp_length)
        symbol[:n_subcarriers*2] = ifft_out  # 2N
        symbol[n_subcarriers*2:] = ifft_out[:cp_length]
        
        signal.append(symbol.tolist())
    
    return np.ravel(np.array(signal))


def DMT_demodulate(f_signal,
                   n_subcarriers=32,
                   pilots=(31,),
                   modulation_format='bpsk',
                   cp_length=32//4,
                   return_symbols = False):
    """
    Demodulate DMT signal to ASCII bits

    Better to glob each DMT symbol length from signal.
    """
    symbols = []
    data = []
    modulation_order = modulations.modulation_order(modulation_format)

    n_pilots = len(pilots)
    n_data_subcarriers = n_subcarriers - n_pilots - 1  # DC (SC 0) is 0
    
    symbol_length = 2 * n_subcarriers + cp_length  # read past CP
    
    while f_signal.readable():
        # serial to parallel, CP removal
        n_read = symbol_length
        strbuf = []
        stahp = False
        for i in range(n_read):
            line = f_signal.readline()
            if line == '':
                stahp = True
                break
            strbuf.append(float(line))
            
        read_buffer = np.array(strbuf)[:symbol_length-cp_length]
        
        buffer = np.zeros(n_subcarriers * modulation_order,
                          dtype=complex)
        buffer[:len(read_buffer)] = read_buffer
        
        # perform FFT and extract first half of buffer, remove DC, pilot
        fft_out = np.fft.fft(buffer)[1:len(buffer)//2 - 1]
        if np.all(fft_out == 0):
            break
        fft_out = fft_out[(np.abs(fft_out) > 0)]  # remove Tx padding
        symbols.append(fft_out.tolist())
        
        # demodulate
        data_buffer = modulations.demodulate_data(fft_out, 
                                                  modulation_format=modulation_format)
        data.append(data_buffer.tolist())
        
        if stahp:
            break
    
    if return_symbols:
        return np.ravel(np.array(symbols))
    else:
        return np.ravel(np.array(data))
