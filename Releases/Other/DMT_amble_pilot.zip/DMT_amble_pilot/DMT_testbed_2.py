# -*- coding: utf-8 -*-
"""
Classful DMT testbed
Created on Mon Nov 11 12:21:21 2024

@author: drm1g20
"""

import numpy as np
import matplotlib.pyplot as plt

import DMT_codec
import sys
import plot_generics
import channel
import modulations
import prbs


"""
Parameters
"""
bits_filename = 'PRBS7'
amble_filename = 'amble'
Tx_filename = 'DMT_signal'

modulation_format = 'qpsk'

# Set to False for BER.
EVM = False

n_subcarriers = 32
cp_length = n_subcarriers // 4


"""
Signal, amble generation
"""
bit_loading = DMT_codec.generate_flat_bit_loading(modulation_format,
                                                  n_subcarriers=n_subcarriers)

amble_bv = DMT_codec.generate_amble_bv(amble_filename,
                                      n_subcarriers=n_subcarriers,
                                      cp_length=cp_length)

amble_symbol = DMT_codec.amble(amble_bv, bit_loading,
                               n_subcarriers=n_subcarriers,
                               cp_length=cp_length)

"""
Plotting
"""
fig,ax = plot_generics.plot_setup("amble", 'sample','something')
ax.plot(amble_symbol.waveform,label='sn 33 d')
plot_generics.plot_show(ax)