# -*- coding: utf-8 -*-
"""
Testbed for DMT
Created on Fri Nov  8 13:52:58 2024

@author: drm1g20
"""

import numpy as np
import matplotlib.pyplot as plt

import DMT_codec
import sys
import plot_generics
import channel
import modulations
import prbs


"""
Parameters
"""
bits_filename = 'PRBS9'
Tx_filename = 'DMT_signal'

modulation_format = 'qpsk'

# Set to False for BER.
EVM = False


"""
Generate signal
"""
Tx_data = np.genfromtxt(bits_filename, delimiter='\n', dtype=int)

prbs.filesize(bits_filename)
f_data = open(bits_filename, 'r')

Tx = DMT_codec.DMT_modulate(f_data,
                  modulation_format=modulation_format,
                  n_subcarriers=32)
f_data.close()

if Tx is None:
    print("DMT_modulate failed. See above errors.")
    sys.exit(0)
    
fig,ax=plt.subplots()
ax.plot(Tx)
ax.set_xlim((0,64+8))
plt.show()
sys.exit(0)
    
"""
Apply channel
"""
Tx = channel.amplitude_noise(Tx, 0.01)
Tx = channel.phase_noise(Tx,0.01)
channel.print_PAPR(Tx)

np.savetxt(Tx_filename, np.transpose(Tx))

"""
Demodulate
"""
prbs.filesize(Tx_filename)
f_signal = open(Tx_filename, 'r')

Rx_data = DMT_codec.DMT_demodulate(f_signal,
               modulation_format=modulation_format,
               n_subcarriers=32,
               return_symbols=EVM)[:len(Tx_data)]  # add synch
"""
Analyse
"""
if EVM:
    Rx_symbols = Rx_data
    
    print("EVM:", modulations.EVM(Rx_symbols, modulation_format), "%")

    fig,ax = plot_generics.plot_setup('3 symbols with added noises, 1 pilot/sym', 
                                      're', 'im')
    plot_generics.plot_constellation(ax, 
                                     Rx_symbols, 
                                     label='DMT ' + bits_filename, 
                                     colour='blue')
    ax.set_ylim((-1.5,1.5))
    ax.set_xlim((-1.5,1.5))
    plot_generics.plot_show(ax)
    
else:
    if bits_filename == 'PRBS7':
        print(Tx_data)
        print(Rx_data.astype(int))

    print("BER:", modulations.BER(Tx_data, Rx_data))


f_signal.close()