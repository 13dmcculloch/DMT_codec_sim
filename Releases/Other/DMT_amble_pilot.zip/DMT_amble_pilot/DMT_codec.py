# -*- coding: utf-8 -*-
"""
DMT codec.

Created on Thu Nov  7 12:26:20 2024

@author: drm1g20
"""

import numpy as np

import modulations
import channel

class DMT_Symbol:
    """
    This also allows anything to be loaded into a DMT symbol allowing us
    to find the amble or CP from arbitrary waveform for synchronisation.
    Using the results from the synch functions here, the parent function
    can then load in the correct data for demodulation.
    """
    def __init__(self, waveform,
                 n_subcarriers=32,
                 pilots=(31,),
                 cp_length=32//4):
        self.waveform = waveform  # False if symbol to be modulated
        self.n_subcarriers = n_subcarriers
        self.pilots = pilots
        self.cp_length = cp_length
        
        self.bv_f = 0  # file object for input data bit vector
        
        self.bit_loading = 0
        
        self.selmap = False
        
        self.buffer = 0  # set to work on existing data
        self.amble_bv = 0  # set to make amble symbol
        self.ifft_h = 0
        self.symbol = 0
        
        
    """
    Modulation functions
    """
    def _read_in(self):
        if not self.bv_f:
            print("Need to specify bit vector file.")
            return
        
        self.bit_load_size = sum(self.bit_loading.values())
        
        # load appropriate number of carriers for bit loading configuration
        n_read = self.bit_load_size * 2   # includes '\n'
        strbuf = self.bv_f.read(n_read)
        if strbuf == '':
            return
        buffer = np.fromstring(strbuf,
                               sep='\n',
                               dtype=int)
        
        # pad with zeroes if buffer incomplete
        if len(buffer) != n_read and len(strbuf) > 0:
            fullbuf = np.zeros(n_read,
                               dtype=int)
            fullbuf[:len(buffer)] = buffer
            buffer = fullbuf
        
        self.buffer = buffer
        
        return buffer
    
        
    def _bit_load(self):
        """
        Return array of OFDM-buffer modulated data from bv_f according to:
        loading = {
            1: (bpsk carriers):
            2: (qpsk carriers):
            ...
            n: (mod-order loaded carriers)  # see modulations.modulation_order
        }
        """
        if np.any(self.amble_bv):
            buffer = self.amble_bv
        # empty buffer <- new symbol
        elif not np.any(self.buffer):
            buffer = self._read_in()
        # full buffer -> continue to modulate on existing data
        
        if buffer is None:
            return 'EOF'
            
        # load each carrier with each modulated bits
        ifft_h = np.zeros(self.n_subcarriers,dtype=complex)
        pos = 0
        buffer_pos = 0
        for carrier, order in self.bit_loading.items():
            if carrier == 0:
                print("Invalid carrier at DC.")
                self.ifft_h = 0
                return
            
            if carrier > self.n_subcarriers - 1:
                print("Invalid subcarrier either at pilot position or \
                      outside.")
                self.ifft_h = 0
                return
            
            ifft_h[pos] = modulations.modulate_bits(buffer[buffer_pos:buffer_pos+order],
                                                  order,
                                                  invert=self.selmap)
            pos += 1
            buffer_pos += order
            
        self.ifft_h = ifft_h
        
        return ifft_h
    
    
    def _pilot(self):
        """
        Pilot is always BPSK, so we BPSK demodulate the last symbol and use
        its value to determine mapping for rest of symbols
        """
        # just makes final sc in ifft_h equal to selmap value
        if self.ifft_h[-1]:
            print("Loaded data register incorrectly.")
            return
        
        # (1, 0) = normal mapping, (-1, 0) = inverted mapping
        self.ifft_h[-1] = complex(np.power(-1, self.selmap), 0)  # BPSK
        
    
    def _hermitian_ifft(self):
        if not np.any(self.ifft_h):
            print("Need to load data register first.")
            return
        
        buffer = np.zeros(self.n_subcarriers,
                          dtype=complex)
        buffer[1:self.n_subcarriers+1] = self.ifft_h
        
        buffer_conj = np.zeros(self.n_subcarriers,
                               dtype=complex)
        buffer_conj[1:] = np.flip(np.conjugate(buffer[1:]))
        
        ifft_bins = np.concatenate((buffer,buffer_conj))

        # perform IFFT
        ifft_out = np.fft.ifft(ifft_bins)
        if not np.all(np.imag(ifft_out) == 0):
            print("IFFT output has imaginary part:")
            print(ifft_out)
            return
        self.ifft_out = np.real(ifft_out)
        
        return ifft_out
    
    
    def _add_cp(self):
        symbol = np.zeros(self.n_subcarriers * 2 + self.cp_length)
        symbol[:self.n_subcarriers*2] = self.ifft_out
        symbol[self.n_subcarriers*2:] = self.ifft_out[:self.cp_length]
        
        self.symbol = symbol
        
        return symbol
        
    
    def modulate(self):
        """
        Sets/returns self.waveform to the lowest PAPR signal out of norm/inv
        """
        self.selmap = False
        bl_res = self._bit_load()
        self._pilot()
        self._hermitian_ifft()
        normal = self._add_cp()
        
        if type(bl_res) == str and bl_res == 'EOF':
            return 'EOF'
        
        print("modulate: Successfully doen first mod")
        
        self.selmap = True
        self._bit_load()  # uses same buffer from previous
        self._pilot()
        self._hermitian_ifft()
        invert = self._add_cp()
        
        print("modulate: Successfully doen second mod")
        
        # compare PAPR of each
        papr_normal = channel.PAPR(normal)[2]
        papr_invert = channel.PAPR(invert)[2]
        
        if papr_normal > papr_invert:
            self.waveform = invert
            print("modulate:invert")
        else:
            self.waveform = normal
            print("modulate:normal")
            
        return self.waveform
        
        
    """
    Demodulation functions
    """  
    def _is_correlated(self, correlation, method, threshold):
        if method == 'threshold':
            # is any part of the correlation function over a threhsold?
            correlation_threshold = threshold  # have to do this prudently
            
            result = np.where(correlation > correlation_threshold)[0]
            
            if result:
                return result
            
        elif method == 'peak':
            # is the peak-to-average of the correlation over a threshold?
            peak_threshold = threshold
            peak = np.max(correlation) / np.mean(correlation)
            
            if peak > peak_threshold:
                return True
        
        else:
            print("Unknown correlation method.")
            return False
        
        return False
        
    
    def is_amble(self, method='threshold', threshold=0.3):
        l = len(self.waveform) // 2 - self.cp_length // 2
        waveform_low = self.waveform[:l]
        waveform_high = np.flip(self.waveform[l:])
        
        correlation = np.correlate(waveform_low, waveform_high,'full')
        
        return self._is_correlated(correlation, method, threshold)
    
    
    def is_cp(self, method='threshold', threshold=0.3):
        # return location of CP if we know it is present
        cp = self.waveform[self.cp_length:]
        
        correlation = np.correlate(cp, 
                                   self.waveform, 
                                   'full')
        
        correlation = np.correlate(self.waveform, 
                                   self.waveform[self.cp_length:len(self.waveform)-self.cp_length],                       
                                   'full')
        
        return self._is_correlated(correlation, method, threshold)
        

def generate_amble_bv(filename,
                      n_subcarriers=32,
                      cp_length=32//4):
    bv_len = 2 * (n_subcarriers - 1 - 1)  # DC and pilot
    bv = np.random.randint(2,size=2*n_subcarriers-1)
    np.savetxt(filename, np.transpose(bv))
    
    return bv
    

def generate_flat_bit_loading(modulation_format,
                              n_subcarriers=32):
    r = range(1,n_subcarriers-1)
    modulation_order = modulations.modulation_order(modulation_format)
    if modulation_order is None:
        print("Failed to generate flat bit loading.")
        return

    bit_loading = {c: modulation_order for c in r}
    
    return bit_loading


def amble(amble_bv,
          bit_loading,
          n_subcarriers=32,
          cp_length=32//4):
    amble_symbol = DMT_Symbol(False,
                              n_subcarriers=n_subcarriers,
                              cp_length=cp_length)
    amble_symbol.bit_loading = bit_loading
    amble_symbol.amble_bv = amble_bv
    
    amble_symbol.modulate()
    
    if amble_symbol.is_amble(method='threshold', threshold=0.3):
        return amble_symbol
    else:
        print("Could not generate amble, symbol does not repeat.")
    
    return amble_symbol


def DMT_modulate(bv_f,
                 amble_sym,
                 bit_loading,
                 n_subcarriers=32,
                 pilots=(31,),
                 cp_length=32//4):
    
    # check if amble agrees with parameters
    amble_len = len(amble_sym.waveform)
    if amble_len != n_subcarriers*2 + cp_length:
        print("Invalid amble length:", amble_len)
        return
    
    if not bv_f.readable():
        print("Bit vector input file is not readable.")
        return
    
    signal = []
    while True:
        sym = DMT_Symbol(False,
                         n_subcarriers=n_subcarriers,
                         pilots=pilots,
                         cp_length=cp_length)
        sym.bv_f = bv_f
        sym.bit_loading = bit_loading
        mod_res = sym.modulate()
        
        if mod_res == 'EOF':
            break
            
        signal.append(mod_res.tolist())
        
        break
        
    return np.ravel(np.array(signal))
    

def DMT_modulate_p(f_data,
                 n_subcarriers=32,
                 pilots=(31,),
                 modulation_format='bpsk',
                 cp_length=32//4):
    """
    Old procedural version
    Modulate ASCII bits in f_data file object to DMT symbols ndarray
    """
    signal = []
    
    n_pilots = len(pilots)
    n_data_subcarriers = n_subcarriers - n_pilots - 1  # DC (SC 0) is 0
    
    modulation_order = modulations.modulation_order(modulation_format)
    
    while f_data.readable():
        # serial to parallel
        n_read = n_data_subcarriers * modulation_order
        strbuf = f_data.read(n_read * 2)  # includes '\n'
        if strbuf == '':
            break
        buffer = np.fromstring(strbuf,
                               sep='\n',
                               dtype=int)
        
        # pad with zeroes if buffer incomplete
        if len(buffer) != n_read and len(strbuf) > 0:
            fullbuf = np.zeros(n_read,
                               dtype=int)
            fullbuf[:len(buffer)] = buffer
            buffer = fullbuf
    
        # mapping
        data = modulations.modulate_data(buffer,
                                         modulation_format=modulation_format)
        pilot_symbol = np.real(np.max(data))
        
        # prepare ifft buffer
        bins = np.zeros(n_subcarriers,
                        dtype=complex)
        bins[1:len(data)+1] = data
        bins[len(bins)-1] = pilot_symbol
        
        bins_conj = np.zeros(n_subcarriers,
                        dtype=complex)
        bins_conj[1:] = np.flip(np.conjugate(bins[1:]))
        
        ifft_bins = np.concatenate((bins, bins_conj))

        # perform IFFT
        ifft_out = np.fft.ifft(ifft_bins)
        if not np.all(np.imag(ifft_out) == 0):
            print("IFFT output has imaginary part:")
            print(ifft_out)
            return
        ifft_out = np.real(ifft_out)
        
        # parallel to serial; add CP
        symbol = np.zeros(n_subcarriers*2 + cp_length)
        symbol[:n_subcarriers*2] = ifft_out  # 2N
        symbol[n_subcarriers*2:] = ifft_out[:cp_length]
        
        signal.append(symbol.tolist())
    
    return np.ravel(np.array(signal))


def DMT_demodulate(f_signal,
                   n_subcarriers=32,
                   pilots=(31,),
                   modulation_format='bpsk',
                   cp_length=32//4,
                   return_symbols = False):
    """
    Demodulate DMT signal to ASCII bits

    Better to glob each DMT symbol length from signal.
    """
    symbols = []
    data = []
    modulation_order = modulations.modulation_order(modulation_format)

    n_pilots = len(pilots)
    n_data_subcarriers = n_subcarriers - n_pilots - 1  # DC (SC 0) is 0
    
    symbol_length = 2 * n_subcarriers + cp_length  # read past CP
    
    while f_signal.readable():
        # serial to parallel
        n_read = symbol_length  # this will need changing in practice
        strbuf = []
        stahp = False
        for i in range(n_read):
            line = f_signal.readline()
            if line == '':
                stahp = True
                break
            strbuf.append(float(line))
            
        # want to KEEP CP, then perform correlations
        read_buffer = np.array(strbuf)[:symbol_length-cp_length]
        
        buffer = np.zeros(n_subcarriers * modulation_order,
                          dtype=complex)
        buffer[:len(read_buffer)] = read_buffer
        
        # perform FFT and extract first half of buffer, remove DC, pilot
        fft_out = np.fft.fft(buffer)[1:len(buffer)//2 - 1]
        if np.all(fft_out == 0):
            break
        fft_out = fft_out[(np.abs(fft_out) > 0)]  # remove Tx padding
        symbols.append(fft_out.tolist())
        
        # demodulate
        data_buffer = modulations.demodulate_data(fft_out, 
                                                  modulation_format=modulation_format)
        data.append(data_buffer.tolist())
        
        if stahp:
            break
    
    if return_symbols:
        return np.ravel(np.array(symbols))
    else:
        return np.ravel(np.array(data))


def amble_p(amble_bv,
              n_subcarriers=32,
              modulation_format='bpsk',
              cp_length=32//4):
    """
    Create a DMT amble symbol. Halfway through the symbol (without CP),
    the symbol repeats, but is flipped in the time domain!
    
    No idea how it does this btw
    """
    n_bits = n_subcarriers - 1
    
    if len(amble_bv) != n_bits:
        print("Length of amble bit vector", len(amble_bv), "is invalid.")
        return
    data = modulations.modulate_data(amble_bv,
                                     modulation_format=modulation_format)
    
    buffer = np.zeros(n_subcarriers,
                      dtype=complex)
    buffer[1:n_subcarriers+1] = data
    
    buffer_conj = np.zeros(n_subcarriers,
                         dtype=complex)
    buffer_conj[1:] = np.flip(np.conjugate(buffer[1:]))
    
    ifft_buffer = np.concatenate((buffer,buffer_conj))
    ifft_buffer = np.fft.ifft(ifft_buffer)
    if not np.all(np.imag(ifft_buffer) == 0):
        print("IFFT output has imaginary part:")
        print(ifft_buffer)
        return
    buffer = np.real(ifft_buffer)

    symbol = np.zeros(n_subcarriers * 2 + cp_length)
    symbol[:n_subcarriers*2] = buffer
    symbol[n_subcarriers*2:] = buffer[:cp_length]
    
    return symbol
    